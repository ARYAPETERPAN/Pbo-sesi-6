# praktikum-inheritance
