package Polimorpysme;

class Overidding {
    void mamalia() {
        System.out.println("Hewan hewan mamalia");
    }
}

class Kangguru extends Overidding {
        
        void mamalia() {
        System.out.println("Kangguru merupakan hewan mamalia");
    }

        void melahirkan() {
        System.out.println("Kangguru hewan yang melahirkan");
    }
}



