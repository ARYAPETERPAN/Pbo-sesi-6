package Percobaan_3;


class Parent {
    // kosong
}


public class Child extends Parent {
    int x;
    public Child() {
        x = 5;
    }
}
